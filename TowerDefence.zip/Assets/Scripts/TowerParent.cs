using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TowerParent : MonoBehaviour
{
    [SerializeField] protected GameObject turret, projectile;

    
}
